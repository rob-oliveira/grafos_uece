function Grafo(nome, cor)
{
	this.nome = nome;
	this.cor = cor;
	this.vertice = new Array();
}
